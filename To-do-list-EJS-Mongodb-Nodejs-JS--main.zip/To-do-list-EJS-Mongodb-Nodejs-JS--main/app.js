const express = require("express");
const bodyParser = require("body-parser");
var app = express()
app.set("view engine", "ejs")
app.use(express.urlencoded({extended:true}))
app.use(express.static('public'))


const mongoose = require("mongoose");
/* make glowing text for something new or creative */
mongoose.connect("mongodb+srv://sahil_:sahil123@cluster0.lty5r6j.mongodb.net/todolist")

const trySchema = new mongoose.Schema({
    name : String
})

const item = mongoose.model("task",trySchema) 

const todo = new item({
    name : "create some videos!!!"
})
const todo1 = new item({
    name : "learn dsa!!!"
})
const todo2 = new item({
    name : "learn database!!!"
})
const todo3 = new item({
    name : "learn node!!!"
})
const todo4 = new item({
    name : "learn react!!!"
})

var example = "working"
var items = []
var result = []

app.get("/",function(req,res){
    item.find().then((result) => {
        res.render("list",{ejes: result})
    }).catch(err=>console.log(err))
})

app.post("/",function(req,res){
    const itemName = req.body.ele1;

    const todoData = new item({
        name:itemName
    })

    todoData.save().then().catch(err=>console.log(err))

    return res.redirect("/")
})


app.post("/delete", function(req, res){
    const checked = req.body.checkbox1;


    item.findByIdAndDelete(checked)
    .then(deletedItem => {
       
        console.log("deleted");
        
        res.redirect("/");
    })
    .catch(err => {
       
        console.error("Error deleting item:", err);
       
        res.status(500).send("Internal Server Error");
    });
 });
app.listen(3000, function(){
    console.log("server started")
})